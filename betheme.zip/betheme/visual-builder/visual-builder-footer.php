<?php

do_action( 'mfn_footer_enqueue' );
/*do_action( 'in_admin_footer' );*/
do_action( 'admin_print_footer_scripts' );
//do_action( 'admin_footer' );

do_action( 'mfn_bebuilder_footer_scripts' );

?>
</body>
</html>
