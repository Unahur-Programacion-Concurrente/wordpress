Pre-made translation files created by Betheme users are included in Betheme Child Theme.
Please download Betheme 'All files' from the Envato downloads section.

Translations are available for the following language codes:

- de_DE
- fa_IR
- pl_PL
- pt_BR
- pt_PT
- ru_RU
- uk

Some translations may be incomplete. If you think you have better translation files and want to share them with other Betheme users, please mailto:muffingroupcom@gmail.com; we will include your translation in the next update. 